
# Dataset Description

## Overview
This directory contains the data crawled from the internet on 2024-02-26. The source urls are listed below. The depth of recursive crawling is set to be 2, which means for each of the source urls, the hyperlinks on this source webpage will also be visited, while the hyperlinks on these linked pages will not be visited.

```python
list_of_sources = [
    "https://lti.cs.cmu.edu/directory/all/154/1",
    "https://enr-apps.as.cmu.edu/open/SOC/SOCServlet/completeSchedule",
    "https://www.cmu.edu/hub/calendar/",
    "https://lti.cs.cmu.edu/learn",
    "https://web.cvent.com/event/ab7f7aba-4e7c-4637-a1fc-dd1f608702c4/websitePage:645d57e4-75eb-4769-b2c0-f201a0bfc6ce?locale=en",
    "https://www.cmu.edu/commencement/schedule/index.html",
    "https://www.cs.cmu.edu/scs25/25things",
    "https://www.cs.cmu.edu/scs25/history",
    "https://www.cmu.edu/about/history.html",
    "https://www.cmu.edu/news/stories/archives/2019/april/spring-carnival-buggy.html",
    "https://athletics.cmu.edu/athletics/tartanfacts",
    "https://athletics.cmu.edu/athletics/mascot/about",
    "https://athletics.cmu.edu/athletics/kiltieband/index",
]
```

## Directory Structure
All data are in .txt format after being processed using the bs4 and unstructuted python package. The data is organized into two directories, html/ and pdf/, according to the original data format. 

There is an additional sample/ directory, which contains the representative data points that is selected among the html/ and pdf/ data, which typically are cleaner and more informative than other data points. They are selected for the purpose of initial high quality question-answer pair generation for our project.

## Post Processing
From all the text files crawled, the files containing no keyword both in the content and the title are removed. Also, files with less than 200 characters are removed. Text files that have "Page_not_found" in the title are also removed.

```python
keywords = [
    "cmu",
    "carnegie",
    "mellon",
    "university",
    "tartans",
    "scotty",
    "pittsburgh",
    "carnival",
    "CMU",
    "Carnegie",
    "Mellon",
    "University",
    "Tartans",
    "Scotty",
    "Pittsburgh",
    "Carnival",
]
```